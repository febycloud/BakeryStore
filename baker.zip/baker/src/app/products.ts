export const items = [
    {
      id:'CU100',
      name: 'Phone XL',
      price: 799,
      img: 'https://material.angular.io/assets/img/examples/shiba2.jpg',
      description:'this is the best cake I have ever had yes mama lala dada',
      allergy:'nuts milk',
      alcohol:'no',
      comment:'this is comment1',
      fat:'30%',
      sugar:'15g/150g',
      calorie:'130kcal'
    },
    {
      id:'CA105',
      name: 'Phone Mini',
      price: 699,
      img: 'https://material.angular.io/assets/img/examples/shiba2.jpg',
      description:'this is the best cake I have ever had yes mama lala dada',
      allergy:'nuts ',
      alcohol:'yes',
      comment:'this is comment2',
      fat:'40%',
      sugar:'20g/150g',
      calorie:'160kcal'
    },
    {
      id:'DS115',
      name: 'Phone Standard',
      price: 299,
      img: 'https://material.angular.io/assets/img/examples/shiba2.jpg',
      description:'this is the best cake I have ever had yes mama lala dada',
      allergy:'nuts milk fish',
      alcohol:'yes',
      comment:'this is comment1',
      fat:'10%',
      sugar:'30g/150g',
      calorie:'345kcal'
    }
  ];